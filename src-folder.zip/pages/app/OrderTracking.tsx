export default function OrderTracking() {
  return <h2 className="text-2xl font-semibold">Order Tracking</h2>
}