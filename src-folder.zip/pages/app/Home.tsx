export default function Home() {
  return <h2 className="text-2xl font-semibold">Customer Home</h2>
}