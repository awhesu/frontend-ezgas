export default function Schedule() {
  return <h2 className="text-2xl font-semibold">Schedule Delivery</h2>
}