export default function Orders() {
  return <h2 className="text-2xl font-semibold">Admin Orders</h2>
}