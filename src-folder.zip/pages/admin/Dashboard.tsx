export default function Dashboard() {
  return <h2 className="text-2xl font-semibold">Admin Dashboard</h2>
}